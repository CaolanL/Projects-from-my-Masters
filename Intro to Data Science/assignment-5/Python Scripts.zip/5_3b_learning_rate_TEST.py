# q53b_learning_rate_plot.py
import numpy as np
import gym
import matplotlib.pyplot as plt

# Configuration
ENV_NAME = "MountainCar-v0"
EPISODES = 1000
MAX_STEPS = 200
POS_BINS = 30
VEL_BINS = 25
ALPHAS = [0.1, 0.3, 0.5, 0.7, 0.9]
GAMMA = 0.9
EPSILON = 0.3          # initial exploration
SEED = 42
GOAL_POS = 0.5


def make_grid(low, high, n_bins):
    """Creates uniform discretization grid."""
    return np.linspace(low, high, n_bins + 1)[1:-1]


def observation_to_state(obs, pos_grid, vel_grid, n_vel_bins):
    """Maps continuous observation (pos, vel) to discrete state index."""
    i = np.digitize(obs[0], pos_grid)
    j = np.digitize(obs[1], vel_grid)
    return i * n_vel_bins + j


def q_update(Q, s, a, r, s_next, done, alpha, gamma):
    """Q-learning update rule."""
    target = r if done else r + gamma * np.max(Q[s_next])
    Q[s, a] += alpha * (target - Q[s, a])


def run(alpha):
    """Run Q-learning with a given alpha and return episode rewards."""
    env = gym.make(ENV_NAME)
    rng = np.random.default_rng(SEED)
    pos_grid = make_grid(env.observation_space.low[0], env.observation_space.high[0], POS_BINS)
    vel_grid = make_grid(env.observation_space.low[1], env.observation_space.high[1], VEL_BINS)

    n_states = POS_BINS * VEL_BINS
    n_actions = env.action_space.n
    Q = np.zeros((n_states, n_actions))
    episode_rewards = []

    epsilon = EPSILON

    for ep in range(EPISODES):
        obs, _ = env.reset(seed=SEED + ep)
        total_reward = 0

        for t in range(MAX_STEPS):
            s = observation_to_state(obs, pos_grid, vel_grid, VEL_BINS)

            # ε-greedy action selection
            if rng.random() < epsilon:
                action = env.action_space.sample()
            else:
                action = int(np.argmax(Q[s]))

            obs_next, r, done, trunc, _ = env.step(action)
            done = done or trunc

            # Reward shaping — give a big reward if reaching the goal
            if obs_next[0] >= GOAL_POS:
                r = 100.0
                done = True

            s_next = observation_to_state(obs_next, pos_grid, vel_grid, VEL_BINS)
            q_update(Q, s, action, r, s_next, done, alpha, GAMMA)

            obs = obs_next
            total_reward += r
            if done:
                break

        episode_rewards.append(total_reward)

    env.close()
    return episode_rewards


def main():
    results = {}
    for alpha in ALPHAS:
        print(f"\nRunning Q-learning with α = {alpha}")
        rewards = run(alpha)
        results[alpha] = rewards

    # Plot average rewards
    plt.figure(figsize=(8, 5))
    for alpha, rewards in results.items():
        moving_avg = np.convolve(rewards, np.ones(20) / 20, mode='valid')
        plt.plot(moving_avg, label=f"α = {alpha}")
    plt.xlabel("Episode")
    plt.ylabel("Average Reward (20-episode moving mean)")
    plt.title("Effect of Learning Rate (α) on Q-learning Performance")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()
