import gym 
#If you have an older version of python use import gym

# the following line implements the environment that you want to use from gym:
env = gym.make("MountainCar-v0")
# to be able to run any gym environment we need call reset first
state = env.reset()
# this is only a short example so we set the steps to 500 later you might want to change that
for i in range(500):
    action = 1
    # env.step updates the environment
    state, reward, done, info = env.step(action)
    # env.render creates the rendering there are several options the library
    # supports. In the example we choose "human" that results in the little video
    # you can see in the pop-up window. If you prefer other output you can change the
    # rendering mode.
    env.render(mode="human")
# In the end we need to close the environment
env.close()