# q53b_learning_rate.py
import numpy as np
if not hasattr(np, "bool8"):
    np.bool8 = np.bool_
import gym
import matplotlib.pyplot as plt

# Configuration
ENV_NAME = "MountainCar-v0"
EPISODES = 500
MAX_STEPS = 200
POS_BINS = 19
VEL_BINS = 15
ALPHAS = [0.1, 0.3, 0.5, 0.7, 0.9]
GAMMA = 0.9
EPSILON = 0.5        # fixed exploration
SEED = 42
GOAL_POS = 0.5

def make_grid(low, high, n_bins):
    return np.linspace(low, high, n_bins + 1)[1:-1]

def obs_to_state(obs, pos_grid, vel_grid, n_vel_bins):
    i = np.digitize(obs[0], pos_grid)
    j = np.digitize(obs[1], vel_grid)
    return i * n_vel_bins + j

def q_update(Q, s, a, r, s_next, done, alpha, gamma):
    target = r if done else r + gamma * np.max(Q[s_next])
    Q[s, a] += alpha * (target - Q[s, a])

def run(alpha):
    env = gym.make(ENV_NAME)
    rng = np.random.default_rng(SEED)
    pos_grid = make_grid(env.observation_space.low[0], env.observation_space.high[0], POS_BINS)
    vel_grid = make_grid(env.observation_space.low[1], env.observation_space.high[1], VEL_BINS)
    n_states = POS_BINS * VEL_BINS
    n_actions = env.action_space.n
    Q = np.zeros((n_states, n_actions))
    episode_rewards = []


    for ep in range(EPISODES):
        obs, _ = env.reset(seed=SEED + ep)
        total_reward = 0
        for t in range(MAX_STEPS):
            s = obs_to_state(obs, pos_grid, vel_grid, VEL_BINS)
            # ε-greedy action selection
            if rng.random() < EPSILON:
                a = env.action_space.sample()
            else:
                a = int(np.argmax(Q[s]))
            obs_next, r, done, trunc, _ = env.step(a)
            done = done or trunc or (obs_next[0] >= GOAL_POS)
            s_next = obs_to_state(obs_next, pos_grid, vel_grid, VEL_BINS)
            q_update(Q, s, a, r, s_next, done, alpha, GAMMA)
            obs = obs_next
            total_reward += r
            if done:
                break
        episode_rewards.append(total_reward)
    env.close()
    return episode_rewards

# Run experiments
results = {alpha: run(alpha) for alpha in ALPHAS}

# Plot
plt.figure(figsize=(8,5))
for alpha, rewards in results.items():
    plt.plot(np.convolve(rewards, np.ones(10)/10, mode='valid'), label=f"α={alpha}")
plt.xlabel("Episode")
plt.ylabel("Avg Reward (10-episode moving mean)")
plt.title("Effect of Learning Rate (α) on Q-learning")
plt.legend()
plt.tight_layout()
plt.show()
