# Python Script for Exercise 5.2 of Assignment 5 #
# Author: Konstantinos Garas
# E-mail: kgaras041@gmail.com // k.gkaras@student.rug.nl
# Created: Sun 12 Oct 2025 @ 13:24:25 +0200
# Modified: Tue 14 Oct 2025 @ 15:32:25 +0200

# Packages
import numpy as np
import gym
import matplotlib.pyplot as plt
import os

# Environmental Variables
from config import *

def moving_avg(x, k=20):
    if len(x) < k:
        return np.array(x, dtype=float)
    c = np.cumsum(np.insert(x, 0, 0.0))
    return (c[k:] - c[:-k]) / k

def make_grid(low, high, n_bins):
    '''
    Function that makes a uniform grid after the required number of bins has been
    parsed as input. The output grid has size of n_bins-1, this will be useful 
    later on.
    '''
    return np.linspace(low, high, n_bins + 1)[1: - 1]

def observation_to_state(obs, pos_grid, vel_grid, n_vel_bins):
    '''
    Turn a 2D grid index (in this case is the position-bin and velocity-bin 
    respectively), into a single 1D state index s. Nothing special, just a simple
    map.
    '''
    i = int(np.digitize(float(obs[0]), pos_grid))   # i = 0, ..., POS_BINS-1
    j = int(np.digitize(float(obs[1]), vel_grid))   # j = 0, ..., VEL_BINS-1
    return i * n_vel_bins + j

def q_update(Q, s, a, r, s_next, done, alpha, gamma):
    '''
    Q-learning update rule drawn from Wikipedia/Lecture Notes.
    '''
    target = r if done else r + gamma * float(Q[s_next].max())
    Q[s, a] += alpha * (target - Q[s, a])

def main():
    # Initialization of the environment from gym
    rng = np.random.default_rng(SEED)
    render_mode = "human" if RENDER else None
    env = gym.make("MountainCar-v0", render_mode = render_mode, max_episode_steps = MAX_STEPS)
        
    # Fetch how many actions the agent can take
    n_actions = env.action_space.n               # should be 3

    # Fetch minimum and maximum values of the elements in the environment, namely
    # the position and velocity.
    pos_min = env.observation_space.low[0]          # min value of the position
    pos_max = env.observation_space.high[0]        # max value of the position
    vel_min = env.observation_space.low[1]          # min value of the velocity
    vel_max = env.observation_space.high[1]        # max value of the velocity

    # Print state space (verify these values with the documentation pages)
    print("\nState Space S = [%.1f, %.1f] x [%.2f, %.2f]" % (pos_min, pos_max,
                                                             vel_min, vel_max))
    
    # Discretize the continuous state space
    pos_grid = make_grid(pos_min, pos_max, POS_BINS)
    vel_grid = make_grid(vel_min, vel_max, VEL_BINS)
    
    # Now that the state space is discrete, compute its cardinality
    n_states = POS_BINS * VEL_BINS
    print(f"Discrete State Space: {POS_BINS} x {VEL_BINS} = {n_states}")

    # Number of discrete bins along each axis = len(grid) + 1
    # Sanity check that catches errors in case something went wrong
    assert (len(pos_grid)+1) == POS_BINS and (len(vel_grid)+1) == VEL_BINS
    
    # Initialize the Q-table. This is an zeros matrix of shape (285, 3)
    Q = np.zeros((n_states, n_actions), dtype=np.float32)   # ensure float
    print(f"Q-matrix shade:", Q.shape)                      # check shape

    # Reset the environment
    state, _ = env.reset(seed=SEED)
    
    if WORKFLOW == "0":
        print("Policy is stochastic (no learning).")
        obs, _ = env.reset(seed=SEED)
        for _ in range(EPISODES):
            action = env.action_space.sample()
            obs, reward, terminated, truncated, _ = env.step(action)
            if RENDER: 
                env.render()
            if terminated or truncated:
                break

    elif WORKFLOW == "1":
        print("Policy is deterministic (no learning).")
        obs, _ = env.reset(seed=SEED)
        for _ in range(EPISODES):
            action = 2 if obs[1] >= 0 else 0
            obs, reward, terminated, truncated, _ = env.step(action)
            if RENDER: 
                env.render()
            if terminated or truncated:
                break

    elif WORKFLOW == "2":
        print(f"Following Q-learning scheme with epsilon={EPSILON}, alpha={ALPHA}, gamma={GAMMA}")
        victories = 0
        episode_returns = []
        episode_steps = []
        for ep in range(EPISODES):
            obs, _ = env.reset(seed=SEED + ep)          # new episode
            ep_return = 0.0
            for t in range(MAX_STEPS):
                s = observation_to_state(obs, pos_grid, vel_grid, VEL_BINS)
                if rng.random() < EPSILON:
                    # Explore
                    action = int(rng.integers(n_actions))
                else:
                    # Learn
                    row = Q[s]
                    maxq = row.max()
                    best_actions = np.flatnonzero(row == maxq)
                    action = int(rng.choice(best_actions))

                # step
                obs_next, r, terminated, truncated, _ = env.step(action)
                success = (obs_next[0] >= GOAL_POS)

                # add early success termination if we reached the hilltop
                done = bool(terminated or truncated or success)

                # Q-learning update
                s_next = observation_to_state(obs_next, pos_grid, vel_grid, VEL_BINS)
                q_update(Q, s, action, r, s_next, done, ALPHA, GAMMA)

                ep_return += r

                if RENDER: 
                    env.render()
                obs = obs_next
                if done:
                    victories += int(success)
                    break

            # Store episode statistics
            episode_returns.append(ep_return)
            episode_steps.append(t+1)

            # Brief training log (just for fun if you want it on)
            print(f"Episode {ep+1}/{EPISODES}: Steps={t+1:>4}, "
                  f"return={ep_return:>6.1f}, {'REACHED TOP' if success else 'STUCK'}")

    else:
        raise ValueError("WORKFLOW must be '0', '1', or '2'. Debug config.py")

    # Close the environment when everything is done
    env.close()
    
    # Compute rolling average and plot the curve
    os.makedirs("output", exist_ok=True)
    
    roll_R = moving_avg(episode_returns, k=20)
    roll_S = moving_avg(episode_steps, k=20)

    # Log the training into a .CSV file
    with open("output/training_log.csv", "w") as f:
        f.write("episode, return, steps\n")
        for i, (R, S) in enumerate(zip(episode_returns, episode_steps), 1):
            f.write(f"{i}, {R}, {S}\n")

    # Plot
    plt.figure(figsize=(8, 4.5))
    plt.plot(episode_returns, alpha=0.25, label="Return (per episode)")
    plt.plot(range(19, len(roll_R)+19), roll_R, label="Return (20-episode MA)")
    plt.xlabel("Episode")
    plt.ylabel("Return")
    plt.title("Mountain Car - Q-learning Scheme")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig("output/learning_curve.png", dpi=150)
    print("Saved learning curve plot in output/")

if __name__ == "__main__":
    main()
