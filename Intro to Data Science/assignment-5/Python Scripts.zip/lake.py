# Implementation of the FrozenLake Reinforcement Learning Scheme #
# Author: Konstantinos Garas
# E-mail: kgaras041@gmail.com // k.gkaras@student.rug.nl
# Created: Tue 14 Oct 2025 @ 17:09:29 +0200
# Modified: Tue 14 Oct 2025 @ 23:18:47 +0200

# Packages
import numpy as np
import gymnasium as gym     # new API
import time

# Hyperparameters
MAP_NAME     = "4x4"
IS_SLIPPERY  = True         # True: stochastic transitions, False: deterministic 
EPISODES     = 5000         # this is fine
ALPHA        = 0.8          # learning rate
GAMMA        = 0.99         # discount
EPSILON      = 0.20         # exploration 
SEED         = 0

# Environment & Q-table
# Create FrozenLake environment. The is_slippery boolean condition influences
# the gnome's actions (ice, transitions are stochastic as per the docs)
env = gym.make("FrozenLake-v1", map_name=MAP_NAME, is_slippery=IS_SLIPPERY)

# Number of states (tiles in the map) & Number of actions (4 compass directions)
nS, nA = env.observation_space.n, env.action_space.n
Q = np.zeros((nS, nA), dtype=float)     # Q-table init
rng = np.random.default_rng(SEED)       # RNG for exploration

def reset_env(seed=None):
    '''
    Reset the environment and return the start state.
    '''
    s, _ = env.reset(seed=seed)
    return int(s)

def step_env(a: int):
    '''
    Take action a, then return (next_state, reward, done (boolean)) tuple.
    '''
    out = env.step(int(a))
    s1, r, term, trunc, _ = out
    return int(s1), float(r), bool(term or trunc)

# Q-learning loop
for ep in range(EPISODES):
    s = reset_env(SEED + ep)
    total = 0.0

    while True:
        # Exploration vs. exploitation
        # With probability epsilon, pick a random action, otherwise fall back
        # to a greedy action following the Q-rule.
        if rng.random() < EPSILON:
            a = int(rng.integers(nA))
        else:
            a = int(np.argmax(Q[s]))
        
        # Step the environment
        s1, r, done = step_env(a)

        # Q-learning update rule (drawn from Wikipedia/Leture Notes)
        Q[s, a] += ALPHA * (r + GAMMA * np.max(Q[s1]) - Q[s, a])
        
        # Move to the next state and accumulate the reward
        s = s1
        total += r

        # The episode ends if the finish line was reached, or if the gnome fell
        # into the bottom of the abyss. Environment's time limit also stops
        # the episode.
        if done:
            # Break the loop if we achieved the goal or reached time limit
            break
    
    # Print only per 500 episodes (probably more wise than what I have done in
    # the mountain and car application, eh well
    if (ep + 1) % 500 == 0:
        print(f"Episode {ep+1}/{EPISODES}: return={total:.1f}")

# Evaluate the policy (exploitation only, no exploration)
pi = np.argmax(Q, axis=1).astype(int)

# Run several greedy test episodes. Success here is determined if the final
# reward reached 1.0.
wins, tests = 0, 500
for k in range(tests):
    s = reset_env(SEED + 1000 + k)
    for _ in range(200):                # hard-cap steps per test episode
        a = int(pi[s])                  # no exploration at all
        s, r, done = step_env(a)
        if done:
            wins += int(r > 0.0)  # reward=1 on goal
            break

# Print success rate and a policy map based on directions
side = int(np.sqrt(nS))
ARROWS = {0: "W", 1: "S", 2: "E", 3: "N"}   # compass
print(f"\nSuccess rate: {wins/tests:.3f} (slippery={IS_SLIPPERY})")
print("Policy (directions):")
for i in range(nS):
    end = "\n" if (i + 1) % side == 0 else " "
    print(ARROWS[int(pi[i])], end=end)

# Animate few episodes in a window :D
play_env = gym.make("FrozenLake-v1", map_name=MAP_NAME,
                    is_slippery=IS_SLIPPERY, render_mode="human")

def reset_play(seed=None):
    '''
    Reset the rendered environment and return the starting state.
    '''
    s, _ = play_env.reset(seed=seed)
    return int(s)

def step_play(a):
    '''
    Step the rendered environment, then return (next_state, reward, done) tuple.
    '''
    out = play_env.step(int(a))
    s1, r, term, trunc, _ = out
    return int(s1), float(r), bool(term or trunc)

# Change this according to how many illustrations you want to see
episodes_to_show = 10

for k in range(episodes_to_show):
    s = reset_play(SEED + 5000 + k)
    done = False
    time.sleep(0.4)                 # Small pause so the start state is visible 
    while not done:
        a = int(pi[s])              # Greedy action from the trained policy
        _, _, done = step_play(a)
        time.sleep(0.25)            # Pace the animation

# Close everything
play_env.close()
env.close()
