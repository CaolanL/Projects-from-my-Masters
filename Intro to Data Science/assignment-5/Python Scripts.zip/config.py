# Workflow Variables for Assignment 5 #
# Author: Konstantinos Garas
# E-mail: kgaras041@gmail.com // k.gkaras@student.rug.nl
# Created: Sun 12 Oct 2025 @ 13:22:56 +0200
# Modified: Tue 14 Oct 2025 @ 15:19:40 +0200

# Define a workflow global variable, with the goal to make 1 Python module that
# solves ALL aspects of exercise 2.

## Possible choices: "0": Stochastic, "1": Simple Deterministic, "2": Q-learning
WORKFLOW = "2"

# Bob Ross mode
RENDER = None

# Loop ranges
# This will be a nested loop, be careful how much you change these numbers
# unless you want to burn your processor
EPISODES = 1000
MAX_STEPS = 500

# Bins for both the position and velocity
# The hint at the assignment suggests 19 bins for the position & 15 for the 
# velocity, so these numbers are the defaults.
POS_BINS = 19
VEL_BINS = 15

# Reinforcement Learning parameters
ALPHA = 0.5                      # learning rate
GAMMA = 0.9                         # discount factor           
SEED = 42                           # static random seed
GOAL_POS = 0.5                      # flags situated on top of the hill
EPSILON = 0.8                     # exploration parameter (if 0, then full exploit)
