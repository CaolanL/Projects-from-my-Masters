# q53d_frozenlake.py
import numpy as np
import gym
import matplotlib.pyplot as plt

# Config
ENV_NAME = "FrozenLake-v1"
EPISODES = 2000
MAX_STEPS = 100
ALPHA = 0.8
GAMMA = 0.95
EPSILON = 0.1
SEED = 42

def q_learning():
    env = gym.make(ENV_NAME, is_slippery=True)
    rng = np.random.default_rng(SEED)
    n_states = env.observation_space.n
    n_actions = env.action_space.n
    Q = np.zeros((n_states, n_actions))
    rewards_per_episode = []

    for ep in range(EPISODES):
        state, _ = env.reset(seed=SEED + ep)
        total_reward = 0
        for t in range(MAX_STEPS):
            if rng.random() < EPSILON:
                action = env.action_space.sample()
            else:
                action = int(np.argmax(Q[state]))
            next_state, reward, done, trunc, _ = env.step(action)
            done = done or trunc
            Q[state, action] += ALPHA * (reward + GAMMA * np.max(Q[next_state]) - Q[state, action])
            state = next_state
            total_reward += reward
            if done:
                break
        rewards_per_episode.append(total_reward)
    env.close()
    return Q, rewards_per_episode

# Train
Q, rewards = q_learning()

# Evaluate learned policy
policy = np.argmax(Q, axis=1)
success_rate = np.mean([r > 0 for r in rewards[-100:]]) * 100

print(f"Learned Policy: {policy}")
print(f"Success rate over last 100 episodes: {success_rate:.2f}%")

# Plot reward progression
plt.plot(np.convolve(rewards, np.ones(100)/100, mode='valid'))
plt.xlabel("Episode")
plt.ylabel("Average reward (100-episode moving mean)")
plt.title("FrozenLake Q-learning Performance")
plt.tight_layout()
plt.show()
